from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Product, Category, Order
from .cart import Cart  # Your session-based cart class
from .utils import get_cart 
 # Your utility to fetch cart from session

# 🏠 Home View
def home(request):
    return render(request, 'home.html')

# 🛍️ Product List View
def product_list(request):
    category_id = request.GET.get('category')
    query = request.GET.get('q')

    products = Product.objects.all()
    if category_id:
        products = products.filter(category_id=category_id)
    if query:
        products = products.filter(name__icontains=query)

    categories = Category.objects.all()
    return render(request, 'shop/product_list.html', {
        'products': products,
        'categories': categories
    })

# 📄 Product Detail View
def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'shop/product_detail.html', {'product': product})

# ➕ Add to Cart
def add_to_cart(request, pk):
    cart = Cart(request)
    product = get_object_or_404(Product, id=pk)
    cart.add(product=product)
    return redirect('view_cart')

# 🧺 View Cart
def view_cart(request):
    cart = Cart(request)
    return render(request, 'shop/cart.html', {'cart': cart})

# ❌ Remove from Cart
def remove_from_cart(request, product_id):
    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    cart.remove(product)
    return redirect('view_cart')

# ✅ Place Order
@login_required
def place_order(request):
    cart = Cart(request)
    if cart:
        # You may want to save order items to DB here
        cart.clear()
        messages.success(request, "Order placed successfully!")
        return redirect('product_list')
    return HttpResponse("Cart is empty!")

# 🧾 Order History
@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'catalog/order_history.html', {'orders': orders})

# 🧾 Bill Page (INVOICE STYLE)

def bill_page(request):
    cart = get_cart(request)  # from your utils
    total = cart.get_total_price() if cart else 0
    return render(request, 'shop/bill_page.html', {
        'cart': cart,
        'total': total
    })