# utils.py
from .cart import Cart

def get_cart(request):
    return Cart(request)
