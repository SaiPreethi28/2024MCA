from django.apps import AppConfig


class DayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'day'
