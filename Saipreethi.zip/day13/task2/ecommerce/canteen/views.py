from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404
from .models import Meal,Category


def meal_list(request):
    category_id = request.GET.get('category')
    query = request.GET.get('q')
    meals = Meal.objects.all()
    if category_id:
        meals = meals.filter(category_id=category_id)
    if query:
        meals = meals.filter(name__icontains=query)
    categories = Category.objects.all()
    return render(request,'canteen/meal_list.html', {'meals': meals, 'categories': categories})


def meal_detail(request, pk):
    ob_meal = get_object_or_404(Meal, pk=pk)
    return render(request, 'meal_detail.html', {'meal': ob_meal})

def add_to_cart(request, pk):
    cart = request.session.get('cart', [])
    if pk not in cart:
        cart.append(pk)
    request.session['cart'] = cart
    return redirect('meal_list')

def view_cart(request):
    cart = request.session.get('cart', [])
    meals = Meal.objects.filter(pk__in=cart)
    return render(request, 'canteen/cart.html', {'meals': meals})