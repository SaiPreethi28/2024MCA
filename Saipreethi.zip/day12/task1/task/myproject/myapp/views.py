from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
# Create your views here.
#def green(request):
    #stu=[{'name':'shiva','marks':90},{'name':'navmohan','marks':85},
         {'name':'shravani','marks':88},{'name':'salma','marks':91}]

    #return render(request,'green.html',{'data': stu})
  

